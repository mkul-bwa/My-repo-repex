def hello(event, context):
    print("hi!")
    return "hello-world"

